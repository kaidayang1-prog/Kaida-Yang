// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {IdentityRegistry} from "./IdentityRegistry.sol";

/// @title StockToken
/// @notice 教学用 Demo：1 个代币 ≈ 托管方持有的 1 股真实美股（1:1 托管支持模型）。
///
/// 设计要点
///  1. 份额账本：内部存"份额(shares)"，对外余额 = shares × multiplier。
///     拆股/合股只改 multiplier，不用遍历持有人，O(1)。
///  2. 合规：转账双方必须在 IdentityRegistry 中通过 KYC，且国家未被限制。
///  3. 储备约束：铸造量不能超过托管方最近一次（且未过期的）储备证明。
///  4. 分红：按份额累计（accumulator 模式），拆股不影响分红计算。
///  5. 熔断：底层股票停牌时可暂停二级转让；监管/私钥丢失场景可强制转移。
///
/// 这是学习用途的简化实现，未经审计，不可用于真实资产。
contract StockToken is IERC20, AccessControl, Pausable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    // ───────────── 角色（生产环境应全部指向多签 + 时间锁） ─────────────
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    bytes32 public constant PAUSER_ROLE = keccak256("PAUSER_ROLE");
    bytes32 public constant CORP_ACTION_ROLE = keccak256("CORP_ACTION_ROLE");
    bytes32 public constant HALT_ROLE = keccak256("HALT_ROLE");
    bytes32 public constant ATTESTOR_ROLE = keccak256("ATTESTOR_ROLE");
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");

    // ───────────── 元数据 ─────────────
    string public name;
    string public symbol;
    uint8 public constant decimals = 18;

    IdentityRegistry public immutable registry;
    IERC20 public immutable dividendToken; // 例如 USDC

    // ───────────── 份额账本 ─────────────
    uint256 private constant PRECISION = 1e18;
    uint256 public multiplier = PRECISION;
    uint256 private _totalShares;
    mapping(address => uint256) private _shares;
    mapping(address => mapping(address => uint256)) private _allowances;

    // ───────────── 分红 ─────────────
    uint256 private constant ACC_PRECISION = 1e36;
    uint256 public accDividendPerShare;
    mapping(address => uint256) private _paidPerShare;
    mapping(address => uint256) private _owed;

    // ───────────── 储备证明 ─────────────
    uint256 public attestedReserve; // 单位：代币（与 totalSupply 同口径）
    uint256 public attestedAt;
    uint256 public maxAttestationAge = 1 days;

    // ───────────── 状态 ─────────────
    bool public tradingHalted;
    uint256 public redeemNonce;

    // ───────────── 事件 ─────────────
    event Split(uint256 numerator, uint256 denominator, uint256 newMultiplier);
    event DividendDeposited(uint256 amount, uint256 accDividendPerShare);
    event DividendClaimed(address indexed holder, uint256 amount);
    event ReserveAttested(uint256 reserve, uint256 timestamp);
    event TradingHaltSet(bool halted);
    event RedeemRequested(address indexed holder, uint256 amount, uint256 indexed nonce);
    event ForcedTransfer(address indexed from, address indexed to, uint256 amount, bytes32 reason);

    // ───────────── 错误 ─────────────
    error NotEligible(address account);
    error TradingHalted();
    error InsufficientBalance();
    error InsufficientAllowance();
    error ZeroAmount();
    error ZeroAddress();
    error StaleAttestation();
    error ExceedsReserve(uint256 requestedSupply, uint256 reserve);
    error InvalidRatio();
    error NothingToClaim();

    constructor(
        string memory name_,
        string memory symbol_,
        IdentityRegistry registry_,
        IERC20 dividendToken_,
        address admin
    ) {
        name = name_;
        symbol = symbol_;
        registry = registry_;
        dividendToken = dividendToken_;
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    // ═════════════════════ ERC-20 视图 ═════════════════════

    function totalSupply() public view returns (uint256) {
        return _totalShares * multiplier / PRECISION;
    }

    function balanceOf(address account) public view returns (uint256) {
        return _shares[account] * multiplier / PRECISION;
    }

    function sharesOf(address account) external view returns (uint256) {
        return _shares[account];
    }

    function allowance(address owner, address spender) external view returns (uint256) {
        return _allowances[owner][spender];
    }

    // ═════════════════════ ERC-20 写操作 ═════════════════════

    function approve(address spender, uint256 amount) external returns (bool) {
        _allowances[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 allowed = _allowances[from][msg.sender];
        if (allowed != type(uint256).max) {
            if (allowed < amount) revert InsufficientAllowance();
            _allowances[from][msg.sender] = allowed - amount;
        }
        _transfer(from, to, amount);
        return true;
    }

    function _transfer(address from, address to, uint256 amount) internal {
        if (to == address(0)) revert ZeroAddress();
        _requireNotPaused();
        if (tradingHalted) revert TradingHalted();
        if (!registry.isEligible(from)) revert NotEligible(from);
        if (!registry.isEligible(to)) revert NotEligible(to);
        _move(from, to, amount);
    }

    /// @dev 不含合规检查的底层转移，供 _transfer 与 forcedTransfer 复用
    function _move(address from, address to, uint256 amount) internal {
        uint256 s = _toShares(from, amount);
        if (_shares[from] < s) revert InsufficientBalance();
        _settle(from);
        _settle(to);
        unchecked {
            _shares[from] -= s;
        }
        _shares[to] += s;
        emit Transfer(from, to, amount);
    }

    /// @dev 转出全部余额时直接用全部份额，避免取整留下粉尘
    function _toShares(address holder, uint256 amount) internal view returns (uint256 s) {
        if (amount == 0) revert ZeroAmount();
        if (amount == balanceOf(holder)) return _shares[holder];
        s = amount * PRECISION / multiplier;
        if (s == 0) revert ZeroAmount();
    }

    // ═════════════════════ 铸造 / 赎回 ═════════════════════

    /// @notice 托管方收到真实股票并出具储备证明后，铸造对应代币
    function mint(address to, uint256 amount) external onlyRole(MINTER_ROLE) {
        _requireNotPaused();
        if (!registry.isEligible(to)) revert NotEligible(to);
        if (!_attestationFresh()) revert StaleAttestation();

        uint256 s = amount * PRECISION / multiplier;
        if (s == 0) revert ZeroAmount();

        uint256 newSupply = (_totalShares + s) * multiplier / PRECISION;
        if (newSupply > attestedReserve) revert ExceedsReserve(newSupply, attestedReserve);

        _settle(to);
        _totalShares += s;
        _shares[to] += s;
        emit Transfer(address(0), to, s * multiplier / PRECISION);
    }

    /// @notice 持有人申请赎回：销毁代币，链下由托管方交付股票或兑付现金
    function redeem(uint256 amount) external {
        _requireNotPaused();
        if (!registry.isEligible(msg.sender)) revert NotEligible(msg.sender);
        uint256 s = _toShares(msg.sender, amount);
        if (_shares[msg.sender] < s) revert InsufficientBalance();

        _settle(msg.sender);
        unchecked {
            _shares[msg.sender] -= s;
        }
        _totalShares -= s;
        emit Transfer(msg.sender, address(0), amount);
        emit RedeemRequested(msg.sender, amount, ++redeemNonce);
    }

    // ═════════════════════ 储备证明 ═════════════════════

    /// @notice 托管方/审计方提交最新托管股数（与代币同口径：1e18 = 1 股）
    function attestReserve(uint256 reserve) external onlyRole(ATTESTOR_ROLE) {
        attestedReserve = reserve;
        attestedAt = block.timestamp;
        emit ReserveAttested(reserve, block.timestamp);
    }

    function setMaxAttestationAge(uint256 age) external onlyRole(DEFAULT_ADMIN_ROLE) {
        maxAttestationAge = age;
    }

    /// @notice 证明未过期，且流通量不超过托管储备
    function isFullyBacked() external view returns (bool) {
        return _attestationFresh() && totalSupply() <= attestedReserve;
    }

    /// @dev 从未证明过（attestedAt == 0）也视为不新鲜
    function _attestationFresh() internal view returns (bool) {
        return attestedAt != 0 && block.timestamp <= attestedAt + maxAttestationAge;
    }

    // ═════════════════════ 公司行动：拆股 ═════════════════════

    /// @notice 拆股/合股。2 拆 1 → (2,1)；1 合 3 → (1,3)
    /// @dev 只改 multiplier；托管方的真实股数同步变化，所以储备证明按同比例调整。
    ///      合股产生的零碎股（fractional）在真实市场按现金处理，这里简化为向下取整。
    function applySplit(uint256 numerator, uint256 denominator) external onlyRole(CORP_ACTION_ROLE) {
        if (numerator == 0 || denominator == 0) revert InvalidRatio();
        uint256 newMultiplier = multiplier * numerator / denominator;
        if (newMultiplier == 0) revert InvalidRatio();
        multiplier = newMultiplier;
        attestedReserve = attestedReserve * numerator / denominator;
        emit Split(numerator, denominator, newMultiplier);
    }

    // ═════════════════════ 公司行动：分红 ═════════════════════

    /// @notice 发行方/托管方把现金分红打入合约，按当前份额比例累计
    /// @dev 简化：按存入时刻的持仓分配，没有实现"股权登记日/除息日"。
    function depositDividend(uint256 amount) external onlyRole(CORP_ACTION_ROLE) {
        if (amount == 0) revert ZeroAmount();
        if (_totalShares == 0) revert ZeroAmount();
        dividendToken.safeTransferFrom(msg.sender, address(this), amount);
        accDividendPerShare += amount * ACC_PRECISION / _totalShares;
        emit DividendDeposited(amount, accDividendPerShare);
    }

    function pendingDividend(address account) public view returns (uint256) {
        return _owed[account] + _shares[account] * (accDividendPerShare - _paidPerShare[account]) / ACC_PRECISION;
    }

    function claimDividend() external nonReentrant returns (uint256 amount) {
        if (!registry.isEligible(msg.sender)) revert NotEligible(msg.sender);
        _settle(msg.sender);
        amount = _owed[msg.sender];
        if (amount == 0) revert NothingToClaim();
        _owed[msg.sender] = 0;
        dividendToken.safeTransfer(msg.sender, amount);
        emit DividendClaimed(msg.sender, amount);
    }

    /// @dev 每次份额变动前先结算，保证分红只属于持有期间的人
    function _settle(address account) internal {
        uint256 acc = accDividendPerShare;
        uint256 s = _shares[account];
        if (s > 0) {
            _owed[account] += s * (acc - _paidPerShare[account]) / ACC_PRECISION;
        }
        _paidPerShare[account] = acc;
    }

    // ═════════════════════ 熔断 / 暂停 / 强制转移 ═════════════════════

    /// @notice 镜像底层股票的停牌状态：停牌期间禁止二级转让
    function setTradingHalted(bool halted) external onlyRole(HALT_ROLE) {
        tradingHalted = halted;
        emit TradingHaltSet(halted);
    }

    function pause() external onlyRole(PAUSER_ROLE) {
        _pause();
    }

    function unpause() external onlyRole(PAUSER_ROLE) {
        _unpause();
    }

    /// @notice 监管指令或私钥丢失时的强制转移；接收方必须合规，操作留痕
    function forcedTransfer(address from, address to, uint256 amount, bytes32 reason)
        external
        onlyRole(COMPLIANCE_ROLE)
    {
        if (to == address(0)) revert ZeroAddress();
        if (!registry.isEligible(to)) revert NotEligible(to);
        _move(from, to, amount);
        emit ForcedTransfer(from, to, amount, reason);
    }
}
