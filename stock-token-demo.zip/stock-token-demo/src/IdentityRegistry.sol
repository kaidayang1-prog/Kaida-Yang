// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/// @title IdentityRegistry
/// @notice 链上 KYC 白名单：只有被合规官登记的地址才能持有股票代币。
/// @dev 真实系统里这一层由 KYC 服务商 / 持牌方在链下审核后写入；
///      链上只存"是否通过"和"国家代码"，不存任何个人信息。
contract IdentityRegistry is AccessControl {
    bytes32 public constant COMPLIANCE_ROLE = keccak256("COMPLIANCE_ROLE");

    struct Identity {
        bool verified;
        uint16 country; // ISO 3166-1 数字代码，例如 840 = 美国, 124 = 加拿大
    }

    mapping(address => Identity) private _identities;
    mapping(uint16 => bool) public countryBlocked;

    event IdentityRegistered(address indexed account, uint16 country);
    event IdentityRemoved(address indexed account);
    event CountryBlockedSet(uint16 indexed country, bool blocked);

    constructor(address admin) {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(COMPLIANCE_ROLE, admin);
    }

    function register(address account, uint16 country) external onlyRole(COMPLIANCE_ROLE) {
        _identities[account] = Identity(true, country);
        emit IdentityRegistered(account, country);
    }

    function remove(address account) external onlyRole(COMPLIANCE_ROLE) {
        delete _identities[account];
        emit IdentityRemoved(account);
    }

    function setCountryBlocked(uint16 country, bool blocked) external onlyRole(COMPLIANCE_ROLE) {
        countryBlocked[country] = blocked;
        emit CountryBlockedSet(country, blocked);
    }

    /// @notice 已通过 KYC 且所在国家未被限制
    function isEligible(address account) public view returns (bool) {
        Identity memory id = _identities[account];
        return id.verified && !countryBlocked[id.country];
    }

    function countryOf(address account) external view returns (uint16) {
        return _identities[account].country;
    }
}
