// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {Test} from "forge-std/Test.sol";
import {StockToken} from "../src/StockToken.sol";
import {IdentityRegistry} from "../src/IdentityRegistry.sol";
import {MockUSDC} from "../src/MockUSDC.sol";

contract StockTokenTest is Test {
    StockToken token;
    IdentityRegistry registry;
    MockUSDC usdc;

    address admin = makeAddr("admin"); // 生产环境 = 多签
    address custodian = makeAddr("custodian"); // 托管方：出具储备证明 + 铸造
    address alice = makeAddr("alice"); // 已 KYC
    address bob = makeAddr("bob"); // 已 KYC
    address mallory = makeAddr("mallory"); // 未 KYC

    uint16 constant CA = 124;
    uint16 constant US = 840;
    uint16 constant SANCTIONED = 408;

    function setUp() public {
        vm.startPrank(admin);
        registry = new IdentityRegistry(admin);
        usdc = new MockUSDC();
        token = new StockToken("Tokenized Apple Inc.", "tAAPL", registry, usdc, admin);

        token.grantRole(token.MINTER_ROLE(), custodian);
        token.grantRole(token.ATTESTOR_ROLE(), custodian);
        token.grantRole(token.CORP_ACTION_ROLE(), admin);
        token.grantRole(token.PAUSER_ROLE(), admin);
        token.grantRole(token.HALT_ROLE(), admin);
        token.grantRole(token.COMPLIANCE_ROLE(), admin);

        registry.register(alice, CA);
        registry.register(bob, US);
        vm.stopPrank();
    }

    // 托管方先证明持有 reserve 股，再铸造
    function _attestAndMint(address to, uint256 reserve, uint256 amount) internal {
        vm.startPrank(custodian);
        token.attestReserve(reserve);
        token.mint(to, amount);
        vm.stopPrank();
    }

    // ───────────── 铸造与储备 ─────────────

    function test_mint_within_reserve() public {
        _attestAndMint(alice, 100e18, 100e18);
        assertEq(token.balanceOf(alice), 100e18);
        assertEq(token.totalSupply(), 100e18);
        assertTrue(token.isFullyBacked());
    }

    function test_mint_reverts_if_exceeds_reserve() public {
        vm.startPrank(custodian);
        token.attestReserve(100e18);
        vm.expectRevert(abi.encodeWithSelector(StockToken.ExceedsReserve.selector, 101e18, 100e18));
        token.mint(alice, 101e18);
        vm.stopPrank();
    }

    function test_mint_reverts_without_fresh_attestation() public {
        // 从未证明过
        vm.prank(custodian);
        vm.expectRevert(StockToken.StaleAttestation.selector);
        token.mint(alice, 1e18);

        // 证明后过期
        vm.prank(custodian);
        token.attestReserve(10e18);
        vm.warp(block.timestamp + 1 days + 1);
        vm.prank(custodian);
        vm.expectRevert(StockToken.StaleAttestation.selector);
        token.mint(alice, 1e18);
    }

    function test_mint_reverts_to_unverified() public {
        vm.startPrank(custodian);
        token.attestReserve(10e18);
        vm.expectRevert(abi.encodeWithSelector(StockToken.NotEligible.selector, mallory));
        token.mint(mallory, 1e18);
        vm.stopPrank();
    }

    function test_only_minter_can_mint() public {
        vm.prank(alice);
        vm.expectRevert();
        token.mint(alice, 1e18);
    }

    // ───────────── 合规转账 ─────────────

    function test_transfer_between_verified() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        token.transfer(bob, 4e18);
        assertEq(token.balanceOf(alice), 6e18);
        assertEq(token.balanceOf(bob), 4e18);
    }

    function test_transfer_to_unverified_reverts() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(StockToken.NotEligible.selector, mallory));
        token.transfer(mallory, 1e18);
    }

    function test_blocked_country_cannot_receive() public {
        vm.startPrank(admin);
        registry.register(mallory, SANCTIONED);
        registry.setCountryBlocked(SANCTIONED, true);
        vm.stopPrank();

        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(StockToken.NotEligible.selector, mallory));
        token.transfer(mallory, 1e18);
    }

    function test_removed_identity_is_frozen() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(admin);
        registry.remove(alice);
        vm.prank(alice);
        vm.expectRevert(abi.encodeWithSelector(StockToken.NotEligible.selector, alice));
        token.transfer(bob, 1e18);
    }

    function test_transferFrom_uses_allowance() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        token.approve(bob, 3e18);
        vm.prank(bob);
        token.transferFrom(alice, bob, 3e18);
        assertEq(token.balanceOf(bob), 3e18);
        vm.prank(bob);
        vm.expectRevert(StockToken.InsufficientAllowance.selector);
        token.transferFrom(alice, bob, 1);
    }

    // ───────────── 熔断 / 暂停 / 强制转移 ─────────────

    function test_halt_blocks_transfer_but_not_after_resume() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(admin);
        token.setTradingHalted(true);

        vm.prank(alice);
        vm.expectRevert(StockToken.TradingHalted.selector);
        token.transfer(bob, 1e18);

        vm.prank(admin);
        token.setTradingHalted(false);
        vm.prank(alice);
        token.transfer(bob, 1e18);
        assertEq(token.balanceOf(bob), 1e18);
    }

    function test_pause_blocks_transfer_and_mint() public {
        _attestAndMint(alice, 10e18, 5e18);
        vm.prank(admin);
        token.pause();

        vm.prank(alice);
        vm.expectRevert();
        token.transfer(bob, 1e18);

        vm.prank(custodian);
        vm.expectRevert();
        token.mint(alice, 1e18);
    }

    function test_forced_transfer_moves_from_frozen_holder() public {
        _attestAndMint(alice, 10e18, 10e18);
        // alice 被冻结（比如私钥泄露），合规官把资产转到她的新地址
        address aliceNew = makeAddr("aliceNew");
        vm.startPrank(admin);
        registry.remove(alice);
        registry.register(aliceNew, CA);
        token.forcedTransfer(alice, aliceNew, 10e18, keccak256("KEY_COMPROMISED"));
        vm.stopPrank();
        assertEq(token.balanceOf(aliceNew), 10e18);
        assertEq(token.balanceOf(alice), 0);
    }

    function test_forced_transfer_needs_role_and_eligible_receiver() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        vm.expectRevert();
        token.forcedTransfer(alice, bob, 1e18, bytes32(0));

        vm.prank(admin);
        vm.expectRevert(abi.encodeWithSelector(StockToken.NotEligible.selector, mallory));
        token.forcedTransfer(alice, mallory, 1e18, bytes32(0));
    }

    // ───────────── 拆股 ─────────────

    function test_forward_split_doubles_balances_and_reserve() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        token.transfer(bob, 4e18);

        vm.prank(admin);
        token.applySplit(2, 1); // 2 拆 1

        assertEq(token.balanceOf(alice), 12e18);
        assertEq(token.balanceOf(bob), 8e18);
        assertEq(token.totalSupply(), 20e18);
        assertEq(token.attestedReserve(), 20e18);
        assertTrue(token.isFullyBacked());
        // 份额没变
        assertEq(token.sharesOf(alice), 6e18);
    }

    function test_reverse_split_halves_balances() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(admin);
        token.applySplit(1, 2); // 1 合 2
        assertEq(token.balanceOf(alice), 5e18);
        assertEq(token.attestedReserve(), 5e18);
    }

    function test_transfer_after_split_uses_new_balance() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(admin);
        token.applySplit(3, 1);
        vm.prank(alice);
        token.transfer(bob, 30e18); // 转出全部（拆后余额 30）
        assertEq(token.balanceOf(alice), 0);
        assertEq(token.balanceOf(bob), 30e18);
    }

    function test_full_balance_transfer_leaves_no_dust_after_odd_split() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(admin);
        token.applySplit(1, 3); // multiplier 无法整除
        uint256 bal = token.balanceOf(alice);
        vm.prank(alice);
        token.transfer(bob, bal);
        assertEq(token.sharesOf(alice), 0);
    }

    function test_split_invalid_ratio_reverts() public {
        vm.startPrank(admin);
        vm.expectRevert(StockToken.InvalidRatio.selector);
        token.applySplit(0, 1);
        vm.expectRevert(StockToken.InvalidRatio.selector);
        token.applySplit(1, 0);
        vm.stopPrank();
    }

    // ───────────── 分红 ─────────────

    function _deposit(uint256 amount) internal {
        usdc.mint(admin, amount);
        vm.startPrank(admin);
        usdc.approve(address(token), amount);
        token.depositDividend(amount);
        vm.stopPrank();
    }

    function test_dividend_split_by_holdings() public {
        _attestAndMint(alice, 100e18, 60e18);
        vm.prank(custodian);
        token.mint(bob, 40e18);

        _deposit(100e6); // 100 USDC

        assertEq(token.pendingDividend(alice), 60e6);
        assertEq(token.pendingDividend(bob), 40e6);

        vm.prank(alice);
        token.claimDividend();
        assertEq(usdc.balanceOf(alice), 60e6);
        assertEq(token.pendingDividend(alice), 0);
    }

    function test_dividend_belongs_to_holder_at_deposit_time() public {
        _attestAndMint(alice, 100e18, 100e18);
        _deposit(100e6); // alice 独享

        // 分红之后 alice 把全部转给 bob，已累计分红仍归 alice
        vm.prank(alice);
        token.transfer(bob, 100e18);
        assertEq(token.pendingDividend(alice), 100e6);
        assertEq(token.pendingDividend(bob), 0);

        _deposit(50e6); // 此后归 bob
        assertEq(token.pendingDividend(bob), 50e6);
        assertEq(token.pendingDividend(alice), 100e6);
    }

    function test_dividend_unaffected_by_split() public {
        _attestAndMint(alice, 100e18, 60e18);
        vm.prank(custodian);
        token.mint(bob, 40e18);

        vm.prank(admin);
        token.applySplit(4, 1); // 拆股后余额翻 4 倍，分红比例不变
        _deposit(100e6);

        assertEq(token.pendingDividend(alice), 60e6);
        assertEq(token.pendingDividend(bob), 40e6);
    }

    function test_claim_reverts_when_nothing_to_claim() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.prank(alice);
        vm.expectRevert(StockToken.NothingToClaim.selector);
        token.claimDividend();
    }

    function test_only_corp_action_role_can_deposit_dividend() public {
        _attestAndMint(alice, 10e18, 10e18);
        usdc.mint(alice, 10e6);
        vm.startPrank(alice);
        usdc.approve(address(token), 10e6);
        vm.expectRevert();
        token.depositDividend(10e6);
        vm.stopPrank();
    }

    // ───────────── 赎回 ─────────────

    function test_redeem_burns_and_emits_request() public {
        _attestAndMint(alice, 10e18, 10e18);
        vm.expectEmit(true, true, false, true);
        emit StockToken.RedeemRequested(alice, 4e18, 1);
        vm.prank(alice);
        token.redeem(4e18);
        assertEq(token.balanceOf(alice), 6e18);
        assertEq(token.totalSupply(), 6e18);
        // 托管方尚未交付股票前，储备大于流通量：仍然是足额的
        assertTrue(token.isFullyBacked());
    }

    // ───────────── 属性测试 ─────────────

    /// 任意合法转账都不改变总供应量，且双方余额之和守恒
    function testFuzz_transfer_conserves_supply(uint128 mintAmt, uint128 sendAmt, uint8 numer, uint8 denom) public {
        mintAmt = uint128(bound(mintAmt, 1e6, 1e30));
        numer = uint8(bound(numer, 1, 10));
        denom = uint8(bound(denom, 1, 10));

        _attestAndMint(alice, mintAmt, mintAmt);
        vm.prank(admin);
        token.applySplit(numer, denom);

        uint256 bal = token.balanceOf(alice);
        vm.assume(bal >= 1e3);
        // 小于 1 份额的粉尘转账会被拒绝（ZeroAmount），所以取值下限设为 1e3 wei
        sendAmt = uint128(bound(sendAmt, 1e3, bal));

        uint256 supplyBefore = token.totalSupply();
        uint256 sharesBefore = token.sharesOf(alice) + token.sharesOf(bob);

        vm.prank(alice);
        token.transfer(bob, sendAmt);

        assertEq(token.totalSupply(), supplyBefore);
        assertEq(token.sharesOf(alice) + token.sharesOf(bob), sharesBefore);
    }

    /// 无论怎么拆股，合约里的分红总额都 >= 所有人可领取之和（不会超发）
    function testFuzz_dividends_never_overpay(uint64 aliceAmt, uint64 bobAmt, uint32 dividend) public {
        aliceAmt = uint64(bound(aliceAmt, 1e6, 1e15));
        bobAmt = uint64(bound(bobAmt, 1e6, 1e15));
        dividend = uint32(bound(dividend, 1e3, 4e9));

        _attestAndMint(alice, uint256(aliceAmt) + bobAmt, aliceAmt);
        vm.prank(custodian);
        token.mint(bob, bobAmt);

        _deposit(dividend);

        uint256 owed = token.pendingDividend(alice) + token.pendingDividend(bob);
        assertLe(owed, dividend);
    }
}
