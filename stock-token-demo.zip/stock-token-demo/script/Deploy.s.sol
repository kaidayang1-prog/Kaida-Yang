// SPDX-License-Identifier: MIT
pragma solidity ^0.8.26;

import {Script, console} from "forge-std/Script.sol";
import {StockToken} from "../src/StockToken.sol";
import {IdentityRegistry} from "../src/IdentityRegistry.sol";
import {MockUSDC} from "../src/MockUSDC.sol";

/// 本地 / 测试网部署。Demo 里所有角色都给部署者，方便演示；
/// 生产环境必须拆分给不同的多签，并加时间锁。
///
///   anvil                      # 另开终端启动本地链
///   forge script script/Deploy.s.sol --rpc-url http://127.0.0.1:8545 \
///     --private-key <anvil 默认私钥> --broadcast
contract Deploy is Script {
    function run() external {
        vm.startBroadcast();
        address me = msg.sender;

        IdentityRegistry registry = new IdentityRegistry(me);
        MockUSDC usdc = new MockUSDC();
        StockToken token = new StockToken("Tokenized Apple Inc.", "tAAPL", registry, usdc, me);

        token.grantRole(token.MINTER_ROLE(), me);
        token.grantRole(token.ATTESTOR_ROLE(), me);
        token.grantRole(token.CORP_ACTION_ROLE(), me);
        token.grantRole(token.PAUSER_ROLE(), me);
        token.grantRole(token.HALT_ROLE(), me);
        token.grantRole(token.COMPLIANCE_ROLE(), me);

        vm.stopBroadcast();

        console.log("IdentityRegistry:", address(registry));
        console.log("MockUSDC:        ", address(usdc));
        console.log("StockToken:      ", address(token));
    }
}
